"""
Example: Using NL2SQL programmatically
This script demonstrates how to use NL2SQL in your own Python applications.
"""
import asyncio
import sys
import os

# Add parent directory to path to import modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from query_executor import NL2SQLApp


async def example_single_query():
    """Example 1: Execute a single query"""
    print("=" * 70)
    print("Example 1: Single Query Execution")
    print("=" * 70 + "\n")
    
    # Initialize application
    app = NL2SQLApp()
    app.initialize()
    
    # Execute query
    result = await app.query(
        "Show me all customers from Germany",
        auto_execute=True
    )
    
    # Access results
    if result['result']:
        print(f"\n✅ Query returned {result['result'].row_count} rows")
        print(f"⏱️  Execution time: {result['result'].execution_time:.3f}s")
    
    # Cleanup
    app.shutdown()


async def example_multiple_queries():
    """Example 2: Execute multiple queries in sequence"""
    print("\n" + "=" * 70)
    print("Example 2: Multiple Queries")
    print("=" * 70 + "\n")
    
    app = NL2SQLApp()
    app.initialize()
    
    queries = [
        "How many customers do we have?",
        "What is the total revenue?",
        "Show top 3 products by price"
    ]
    
    for i, query in enumerate(queries, 1):
        print(f"\n📍 Query {i}/{len(queries)}")
        print("-" * 70)
        result = await app.query(query, auto_execute=True)
        
        if result['result']:
            print(f"✅ Found {result['result'].row_count} rows")
    
    app.shutdown()


async def example_query_analysis():
    """Example 3: Analyze query without execution"""
    print("\n" + "=" * 70)
    print("Example 3: Query Analysis (No Execution)")
    print("=" * 70 + "\n")
    
    app = NL2SQLApp()
    app.initialize()
    
    # Translate but don't execute
    result = await app.query(
        "What are the top 10 customers by total spending?",
        auto_execute=False
    )
    
    translation = result['translation']
    print(f"\n📝 Generated SQL:")
    print(translation.sql)
    print(f"\n💡 Explanation:")
    print(translation.explanation)
    print(f"\n🎯 Intent: {translation.intent.value}")
    print(f"\n🔒 Is Safe: {translation.is_safe}")
    
    app.shutdown()


async def example_error_handling():
    """Example 4: Handling errors gracefully"""
    print("\n" + "=" * 70)
    print("Example 4: Error Handling")
    print("=" * 70 + "\n")
    
    app = NL2SQLApp()
    app.initialize()
    
    # Try an ambiguous or problematic query
    queries = [
        "Show me data",  # Ambiguous
        "Delete all customers",  # Blocked by safety
        "Show me products from nonexistent_table"  # Invalid table
    ]
    
    for query in queries:
        print(f"\n🔍 Testing: {query}")
        print("-" * 70)
        
        try:
            result = await app.query(query, auto_execute=True)
            
            if not result['translation'].is_safe:
                print("⚠️  Query blocked by safety validation")
            elif not result['result']:
                print("⚠️  Query translation completed but execution failed")
            else:
                print("✅ Query executed successfully")
                
        except Exception as e:
            print(f"❌ Error: {str(e)}")
    
    app.shutdown()


async def example_custom_configuration():
    """Example 5: Using custom configuration"""
    print("\n" + "=" * 70)
    print("Example 5: Custom Configuration")
    print("=" * 70 + "\n")
    
    # Create custom configuration
    custom_config = {
        "github_token": os.getenv("GITHUB_TOKEN"),
        "model_endpoint": "https://models.github.ai/inference/",
        "model_name": "openai/gpt-4.1-mini",
        "database_type": "sqlite",
        "database_path": "./sample_data.db",
        "allow_write_operations": False,
        "max_result_rows": 5,  # Limit to 5 rows
        "query_timeout_seconds": 10
    }
    
    app = NL2SQLApp(config=custom_config)
    app.initialize()
    
    print("Using custom configuration:")
    print(f"  • Model: {custom_config['model_name']}")
    print(f"  • Max rows: {custom_config['max_result_rows']}")
    print(f"  • Write ops: {custom_config['allow_write_operations']}")
    
    result = await app.query("Show all customers", auto_execute=True)
    
    if result['result']:
        print(f"\n✅ Results limited to {result['result'].row_count} rows (as configured)")
    
    app.shutdown()


async def main():
    """Run all examples"""
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                   NL2SQL - Programming Examples                      ║
║                                                                       ║
║  This script demonstrates how to use NL2SQL in your applications     ║
╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    try:
        # Run examples
        await example_single_query()
        await example_multiple_queries()
        await example_query_analysis()
        await example_error_handling()
        await example_custom_configuration()
        
        print("\n" + "=" * 70)
        print("✅ All examples completed successfully!")
        print("=" * 70)
        print("\n💡 Next Steps:")
        print("  1. Modify these examples for your use case")
        print("  2. Connect to your own database")
        print("  3. Integrate into your application")
        print("  4. Check README.md for full API documentation")
        print()
        
    except Exception as e:
        print(f"\n❌ Error running examples: {str(e)}")
        print("\n💡 Make sure you have:")
        print("  1. Created .env file with GITHUB_TOKEN")
        print("  2. Run create_sample_db.py")
        print("  3. Installed all dependencies")


if __name__ == "__main__":
    asyncio.run(main())
