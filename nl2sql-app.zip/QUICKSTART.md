# 🚀 Quick Start Guide - NL2SQL

Get up and running with NL2SQL in 5 minutes!

## Prerequisites Checklist

- [ ] Python 3.8+ installed
- [ ] GitHub account (for free model access)
- [ ] 5 minutes of your time

## Step-by-Step Setup

### 1️⃣ Install Dependencies (2 minutes)

Open terminal/PowerShell in the `C:/nl2sql-app` directory:

```powershell
pip install -r requirements.txt
```

**Important**: Make sure `agent-framework-azure-ai` installs with the `--pre` flag (it's included in requirements.txt).

### 2️⃣ Get Your GitHub Token (1 minute)

1. Go to: https://github.com/settings/tokens
2. Click "Generate new token" → "Generate new token (classic)"
3. Give it a name: "NL2SQL App"
4. Select scopes: (no special scopes needed for model access)
5. Click "Generate token"
6. **Copy the token immediately** (you won't see it again!)

### 3️⃣ Configure Application (1 minute)

1. Copy the example configuration:
```powershell
copy .env.example .env
```

2. Edit `.env` file and add your token:
```env
GITHUB_TOKEN=ghp_paste_your_token_here
```

That's it! Leave other settings as default.

### 4️⃣ Create Sample Database (30 seconds)

```powershell
python create_sample_db.py
```

You should see:
```
✅ Sample database created successfully: sample_data.db

Database contains:
  • 10 customers from different countries
  • 15 products across multiple categories
  • 50 orders with various statuses
  • 150 order items
```

### 5️⃣ Launch the Application (30 seconds)

```powershell
cd src
python cli.py
```

You should see the welcome banner and prompt:

```
======================================================================
        🚀 Natural Language to SQL Interface 🚀
======================================================================

🚀 Initializing NL2SQL Application...
✓ Connected to sqlite database
✓ Loaded schema: 4 tables
✓ Initialized NL2SQL engine with model: openai/gpt-4.1-mini
✓ Query executor ready

============================================================
✅ NL2SQL Application Ready!
============================================================

💬 Your question: 
```

## 🎯 Try These First Queries

### Query 1: Simple Selection
```
Show me all customers from Germany
```

### Query 2: Aggregation
```
What is the total revenue by country?
```

### Query 3: Join Query
```
Show customer names with their orders
```

### Query 4: Top N
```
Show top 5 customers by total spending
```

## 📋 Useful Commands

While in the application:

- `help` - Show all available commands
- `examples` - Display more query examples
- `schema` - View your database structure
- `clear` - Clear the screen
- `exit` - Quit application

## ⚡ Tips for Success

### Writing Good Queries

✅ **Good Examples:**
- "Show me all customers from Germany"
- "What are the top 10 products by sales?"
- "Find orders placed in December 2024"

❌ **Avoid:**
- Single words like "customers" or "sales"
- Extremely vague questions
- Multiple unrelated questions in one

### Understanding the Output

Each query shows:
1. **Generated SQL** - The actual SQL query created
2. **Explanation** - How your question was interpreted
3. **Intent** - The type of query (filtering, aggregation, etc.)
4. **Validation** - Safety checks performed
5. **Results** - Formatted table with data

Example output:
```
📝 Generated SQL:
SELECT country, SUM(total_amount) as revenue
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY country
ORDER BY revenue DESC;

💡 Explanation:
This query calculates total revenue for each country by joining orders with customers
and grouping by country.

🎯 Query Intent: AGGREGATION

⚠️  Validation:
  ✓ SQL validation passed

✅ Query is safe. Executing...

📊 Results (8 rows in 0.005s):
```

## 🔧 Troubleshooting

### Issue: "GITHUB_TOKEN not found"
**Fix**: Make sure you created `.env` file and added your token

### Issue: "Module not found: agent_framework"
**Fix**: Run `pip install agent-framework-azure-ai --pre`

### Issue: "Database file not found"
**Fix**: Run `python create_sample_db.py` from the root directory

### Issue: Rate limit errors
**Solution**: GitHub Models free tier has limits. Wait a few minutes or:
- Use a different model: Change `MODEL_NAME` in `.env`
- Consider upgrading to paid tier for higher limits

## 🎓 Next Steps

Once you're comfortable with basic queries:

1. **Try Complex Queries**: Joins, subqueries, aggregations
2. **Connect Your Own Database**: Update `.env` with your database credentials
3. **Explore Different Models**: Try `openai/gpt-4.1` or `openai/o1-mini`
4. **Use Programmatically**: Import as Python library (see README.md)

## 📖 Learn More

- Full documentation: [README.md](README.md)
- Database configuration: [README.md#database-configuration](README.md#database-configuration)
- API reference: [README.md#api-reference](README.md#api-reference)

## ✨ Example Session

Here's what a typical session looks like:

```
💬 Your question: Show me all customers from Germany

🤔 Processing: Show me all customers from Germany
⏳ Translating to SQL...

📝 Generated SQL:
SELECT *
FROM customers
WHERE country = 'Germany';

💡 Explanation:
Retrieves all customer records where country is Germany.

🎯 Query Intent: FILTERING

✅ Query is safe. Executing...

📊 Results (1 rows in 0.003s):
╒═══════════════╤══════════════╤═════════════╤═══════════════════╤═══════════╕
│   customer_id │ first_name   │ last_name   │ email             │ country   │
╞═══════════════╪══════════════╪═════════════╪═══════════════════╪═══════════╡
│             4 │ Emma         │ Brown       │ emma.brown@...    │ Germany   │
╘═══════════════╧══════════════╧═════════════╧═══════════════════╧═══════════╛

💬 Your question: What's the average order value?

🤔 Processing: What's the average order value?
⏳ Translating to SQL...

📝 Generated SQL:
SELECT AVG(total_amount) as avg_order_value
FROM orders;

💡 Explanation:
Calculates the average order value across all orders.

🎯 Query Intent: AGGREGATION

✅ Query is safe. Executing...

📊 Results (1 rows in 0.002s):
╒════════════════════╕
│   avg_order_value  │
╞════════════════════╡
│             245.67 │
╘════════════════════╛
```

## 🎉 You're Ready!

You now have a working Natural Language to SQL interface!

**Happy querying! 🚀**

---

Need help? Check the full [README.md](README.md) or open an issue on GitHub.
