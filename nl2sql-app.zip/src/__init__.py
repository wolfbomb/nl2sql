"""
Package initialization for NL2SQL application
"""
__version__ = "1.0.0"
__author__ = "NL2SQL Team"
