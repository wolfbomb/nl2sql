"""
Database Connection Layer
Provides abstraction for multiple database types with schema introspection.
"""
import os
import sqlite3
from typing import Optional, List, Dict, Any, Tuple
from abc import ABC, abstractmethod
from dataclasses import dataclass
import logging

try:
    import psycopg2
    import psycopg2.extras
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

try:
    import pymssql
    MSSQL_AVAILABLE = True
except ImportError:
    MSSQL_AVAILABLE = False

try:
    import mysql.connector
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False


logger = logging.getLogger(__name__)


@dataclass
class QueryResult:
    """Result of a database query"""
    columns: List[str]
    rows: List[Tuple]
    row_count: int
    execution_time: float


class DatabaseConnection(ABC):
    """Abstract base class for database connections"""
    
    @abstractmethod
    def connect(self) -> None:
        """Establish database connection"""
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Close database connection"""
        pass
    
    @abstractmethod
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> QueryResult:
        """Execute a SELECT query"""
        pass
    
    @abstractmethod
    def get_schema_info(self) -> Dict[str, Any]:
        """Get database schema information"""
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        pass


class SQLiteConnection(DatabaseConnection):
    """SQLite database connection"""
    
    def __init__(self, database_path: str):
        self.database_path = database_path
        self.connection = None
    
    def connect(self) -> None:
        """Establish SQLite connection"""
        try:
            self.connection = sqlite3.connect(self.database_path)
            self.connection.row_factory = sqlite3.Row
            logger.info(f"Connected to SQLite database: {self.database_path}")
        except Exception as e:
            logger.error(f"Failed to connect to SQLite: {e}")
            raise
    
    def disconnect(self) -> None:
        """Close SQLite connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
            logger.info("Disconnected from SQLite database")
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> QueryResult:
        """Execute a SELECT query"""
        import time
        start_time = time.time()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            columns = [description[0] for description in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            execution_time = time.time() - start_time
            
            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time=execution_time
            )
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get SQLite schema information"""
        schema = {"tables": {}, "relationships": []}
        
        try:
            cursor = self.connection.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
            """)
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                # Get column information
                cursor.execute(f"PRAGMA table_info({table})")
                columns = []
                for row in cursor.fetchall():
                    col_info = {
                        "name": row[1],
                        "type": row[2],
                        "nullable": not row[3],
                        "primary_key": bool(row[5])
                    }
                    columns.append(col_info)
                
                schema["tables"][table] = columns
                
                # Get foreign keys
                cursor.execute(f"PRAGMA foreign_key_list({table})")
                for row in cursor.fetchall():
                    schema["relationships"].append({
                        "from_table": table,
                        "from_column": row[3],
                        "to_table": row[2],
                        "to_column": row[4]
                    })
            
            return schema
            
        except Exception as e:
            logger.error(f"Failed to get schema info: {e}")
            raise
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            self.connection.execute("SELECT 1")
            return True
        except:
            return False


class PostgreSQLConnection(DatabaseConnection):
    """PostgreSQL database connection"""
    
    def __init__(self, host: str, port: int, database: str, user: str, password: str):
        if not POSTGRES_AVAILABLE:
            raise ImportError("psycopg2 not installed. Install with: pip install psycopg2-binary")
        
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None
    
    def connect(self) -> None:
        """Establish PostgreSQL connection"""
        try:
            self.connection = psycopg2.connect(
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            logger.info(f"Connected to PostgreSQL database: {self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to PostgreSQL: {e}")
            raise
    
    def disconnect(self) -> None:
        """Close PostgreSQL connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
            logger.info("Disconnected from PostgreSQL database")
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> QueryResult:
        """Execute a SELECT query"""
        import time
        start_time = time.time()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            execution_time = time.time() - start_time
            
            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time=execution_time
            )
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get PostgreSQL schema information"""
        schema = {"tables": {}, "relationships": []}
        
        try:
            cursor = self.connection.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
            """)
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                # Get column information
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable
                    FROM information_schema.columns
                    WHERE table_name = %s AND table_schema = 'public'
                    ORDER BY ordinal_position
                """, (table,))
                
                columns = []
                for row in cursor.fetchall():
                    col_info = {
                        "name": row[0],
                        "type": row[1],
                        "nullable": row[2] == 'YES'
                    }
                    columns.append(col_info)
                
                schema["tables"][table] = columns
                
                # Get foreign keys
                cursor.execute("""
                    SELECT
                        kcu.column_name,
                        ccu.table_name AS foreign_table_name,
                        ccu.column_name AS foreign_column_name
                    FROM information_schema.table_constraints AS tc
                    JOIN information_schema.key_column_usage AS kcu
                        ON tc.constraint_name = kcu.constraint_name
                    JOIN information_schema.constraint_column_usage AS ccu
                        ON ccu.constraint_name = tc.constraint_name
                    WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name = %s
                """, (table,))
                
                for row in cursor.fetchall():
                    schema["relationships"].append({
                        "from_table": table,
                        "from_column": row[0],
                        "to_table": row[1],
                        "to_column": row[2]
                    })
            
            return schema
            
        except Exception as e:
            logger.error(f"Failed to get schema info: {e}")
            raise
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            return True
        except:
            return False


class MySQLConnection(DatabaseConnection):
    """MySQL database connection"""
    
    def __init__(self, host: str, port: int, database: str, user: str, password: str):
        if not MYSQL_AVAILABLE:
            raise ImportError("mysql-connector-python not installed. Install with: pip install mysql-connector-python")
        
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None
    
    def connect(self) -> None:
        """Establish MySQL connection"""
        try:
            self.connection = mysql.connector.connect(
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            logger.info(f"Connected to MySQL database: {self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to MySQL: {e}")
            raise
    
    def disconnect(self) -> None:
        """Close MySQL connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
            logger.info("Disconnected from MySQL database")
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> QueryResult:
        """Execute a SELECT query"""
        import time
        start_time = time.time()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            execution_time = time.time() - start_time
            
            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time=execution_time
            )
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get MySQL schema information"""
        schema = {"tables": {}, "relationships": []}
        
        try:
            cursor = self.connection.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = %s AND table_type = 'BASE TABLE'
            """, (self.database,))
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                # Get column information
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable
                    FROM information_schema.columns
                    WHERE table_name = %s AND table_schema = %s
                    ORDER BY ordinal_position
                """, (table, self.database))
                
                columns = []
                for row in cursor.fetchall():
                    col_info = {
                        "name": row[0],
                        "type": row[1],
                        "nullable": row[2] == 'YES'
                    }
                    columns.append(col_info)
                
                schema["tables"][table] = columns
                
                # Get foreign keys
                cursor.execute("""
                    SELECT
                        column_name,
                        referenced_table_name,
                        referenced_column_name
                    FROM information_schema.key_column_usage
                    WHERE table_name = %s
                        AND table_schema = %s
                        AND referenced_table_name IS NOT NULL
                """, (table, self.database))
                
                for row in cursor.fetchall():
                    schema["relationships"].append({
                        "from_table": table,
                        "from_column": row[0],
                        "to_table": row[1],
                        "to_column": row[2]
                    })
            
            return schema
            
        except Exception as e:
            logger.error(f"Failed to get schema info: {e}")
            raise
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            return True
        except:
            return False


class MSSQLConnection(DatabaseConnection):
    """Microsoft SQL Server database connection"""
    
    def __init__(self, host: str, port: int, database: str, user: str, password: str):
        if not MSSQL_AVAILABLE:
            raise ImportError("pymssql not installed. Install with: pip install pymssql")
        
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None
    
    def connect(self) -> None:
        """Establish MSSQL connection"""
        try:
            self.connection = pymssql.connect(
                server=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            logger.info(f"Connected to MSSQL database: {self.database}")
        except Exception as e:
            logger.error(f"Failed to connect to MSSQL: {e}")
            raise
    
    def disconnect(self) -> None:
        """Close MSSQL connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
            logger.info("Disconnected from MSSQL database")
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> QueryResult:
        """Execute a SELECT query"""
        import time
        start_time = time.time()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            execution_time = time.time() - start_time
            
            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time=execution_time
            )
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get MSSQL schema information"""
        schema = {"tables": {}, "relationships": []}
        
        try:
            cursor = self.connection.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_type = 'BASE TABLE'
            """)
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                # Get column information
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable
                    FROM information_schema.columns
                    WHERE table_name = %s
                    ORDER BY ordinal_position
                """, (table,))
                
                columns = []
                for row in cursor.fetchall():
                    col_info = {
                        "name": row[0],
                        "type": row[1],
                        "nullable": row[2] == 'YES'
                    }
                    columns.append(col_info)
                
                schema["tables"][table] = columns
                
                # Get foreign keys
                cursor.execute("""
                    SELECT
                        COL_NAME(fc.parent_object_id, fc.parent_column_id) AS column_name,
                        OBJECT_NAME(fc.referenced_object_id) AS referenced_table_name,
                        COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS referenced_column_name
                    FROM sys.foreign_keys AS f
                    INNER JOIN sys.foreign_key_columns AS fc
                        ON f.object_id = fc.constraint_object_id
                    WHERE OBJECT_NAME(f.parent_object_id) = %s
                """, (table,))
                
                for row in cursor.fetchall():
                    schema["relationships"].append({
                        "from_table": table,
                        "from_column": row[0],
                        "to_table": row[1],
                        "to_column": row[2]
                    })
            
            return schema
            
        except Exception as e:
            logger.error(f"Failed to get schema info: {e}")
            raise
    
    def test_connection(self) -> bool:
        """Test if connection is alive"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            return True
        except:
            return False


def create_connection(
    database_type: str,
    **kwargs
) -> DatabaseConnection:
    """
    Factory function to create appropriate database connection.
    
    Args:
        database_type: Type of database (sqlite, postgresql, mysql, mssql)
        **kwargs: Database-specific connection parameters
        
    Returns:
        DatabaseConnection instance
    """
    database_type = database_type.lower()
    
    if database_type == "sqlite":
        return SQLiteConnection(
            database_path=kwargs.get("database_path", "database.db")
        )
    elif database_type == "postgresql":
        return PostgreSQLConnection(
            host=kwargs.get("host", "localhost"),
            port=kwargs.get("port", 5432),
            database=kwargs.get("database", "postgres"),
            user=kwargs.get("user", "postgres"),
            password=kwargs.get("password", "")
        )
    elif database_type == "mysql":
        return MySQLConnection(
            host=kwargs.get("host", "localhost"),
            port=kwargs.get("port", 3306),
            database=kwargs.get("database", "mysql"),
            user=kwargs.get("user", "root"),
            password=kwargs.get("password", "")
        )
    elif database_type == "mssql":
        return MSSQLConnection(
            host=kwargs.get("host", "localhost"),
            port=kwargs.get("port", 1433),
            database=kwargs.get("database", "master"),
            user=kwargs.get("user", "sa"),
            password=kwargs.get("password", "")
        )
    else:
        raise ValueError(f"Unsupported database type: {database_type}")
