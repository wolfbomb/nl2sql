"""
Query Execution Engine
Handles safe execution of SQL queries with result formatting.
"""
import os
import asyncio
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from tabulate import tabulate
from colorama import Fore, Style, init

from database import DatabaseConnection, QueryResult
from nl2sql_engine import NL2SQLEngine, NL2SQLResult, SchemaInfo


# Initialize colorama for cross-platform colored output
init(autoreset=True)


class QueryExecutor:
    """
    Executes SQL queries safely with result formatting and error handling.
    """
    
    def __init__(
        self,
        db_connection: DatabaseConnection,
        nl2sql_engine: NL2SQLEngine,
        max_result_rows: int = 100,
        timeout_seconds: int = 30
    ):
        """
        Initialize query executor.
        
        Args:
            db_connection: Database connection instance
            nl2sql_engine: NL2SQL engine instance
            max_result_rows: Maximum number of rows to return
            timeout_seconds: Query timeout in seconds
        """
        self.db_connection = db_connection
        self.nl2sql_engine = nl2sql_engine
        self.max_result_rows = max_result_rows
        self.timeout_seconds = timeout_seconds
    
    async def execute_natural_language_query(
        self,
        natural_language_query: str,
        auto_execute: bool = True
    ) -> Dict[str, Any]:
        """
        Execute a natural language query.
        
        Args:
            natural_language_query: User's question in natural language
            auto_execute: Whether to automatically execute safe queries
            
        Returns:
            Dict containing translation result and query result
        """
        print(f"\n{Fore.CYAN}🤔 Processing: {Style.BRIGHT}{natural_language_query}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}⏳ Translating to SQL...{Style.RESET_ALL}\n")
        
        # Translate to SQL
        nl2sql_result = await self.nl2sql_engine.translate(natural_language_query)
        
        # Display SQL
        formatted_sql = self.nl2sql_engine.format_sql(nl2sql_result.sql)
        print(f"{Fore.GREEN}📝 Generated SQL:{Style.RESET_ALL}")
        print(f"{Fore.WHITE}{Style.BRIGHT}{formatted_sql}{Style.RESET_ALL}\n")
        
        # Display explanation
        print(f"{Fore.CYAN}💡 Explanation:{Style.RESET_ALL}")
        print(f"{nl2sql_result.explanation}\n")
        
        # Display intent
        print(f"{Fore.MAGENTA}🎯 Query Intent: {nl2sql_result.intent.value.upper()}{Style.RESET_ALL}\n")
        
        # Display validation messages
        if nl2sql_result.validation_messages:
            print(f"{Fore.YELLOW}⚠️  Validation:{Style.RESET_ALL}")
            for msg in nl2sql_result.validation_messages:
                if "BLOCKED" in msg:
                    print(f"{Fore.RED}  ✗ {msg}{Style.RESET_ALL}")
                else:
                    print(f"{Fore.GREEN}  ✓ {msg}{Style.RESET_ALL}")
            print()
        
        # Execute if safe
        query_result = None
        if nl2sql_result.is_safe:
            if auto_execute:
                print(f"{Fore.GREEN}✅ Query is safe. Executing...{Style.RESET_ALL}\n")
                query_result = self._execute_sql(nl2sql_result.sql)
            else:
                print(f"{Fore.YELLOW}⚠️  Query is safe but not auto-executing. Use --execute flag to run.{Style.RESET_ALL}\n")
        else:
            print(f"{Fore.RED}❌ Query blocked for safety reasons. Not executing.{Style.RESET_ALL}\n")
        
        return {
            "translation": nl2sql_result,
            "result": query_result
        }
    
    def _execute_sql(self, sql: str) -> Optional[QueryResult]:
        """
        Execute SQL query with timeout and result limiting.
        
        Args:
            sql: SQL query to execute
            
        Returns:
            QueryResult or None if execution fails
        """
        try:
            result = self.db_connection.execute_query(sql)
            
            # Limit results
            if result.row_count > self.max_result_rows:
                print(f"{Fore.YELLOW}⚠️  Result limited to {self.max_result_rows} rows (total: {result.row_count}){Style.RESET_ALL}\n")
                result.rows = result.rows[:self.max_result_rows]
            
            # Display results
            self._display_results(result)
            
            return result
            
        except Exception as e:
            print(f"{Fore.RED}❌ Execution Error: {str(e)}{Style.RESET_ALL}\n")
            return None
    
    def _display_results(self, result: QueryResult) -> None:
        """
        Display query results in a formatted table.
        
        Args:
            result: Query result to display
        """
        if result.row_count == 0:
            print(f"{Fore.YELLOW}📭 No results found{Style.RESET_ALL}\n")
            return
        
        # Format table
        table = tabulate(
            result.rows,
            headers=result.columns,
            tablefmt="fancy_grid",
            numalign="right",
            stralign="left"
        )
        
        print(f"{Fore.GREEN}📊 Results ({result.row_count} rows in {result.execution_time:.3f}s):{Style.RESET_ALL}\n")
        print(table)
        print()


class NL2SQLApp:
    """
    Main application class for NL2SQL system.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize NL2SQL application.
        
        Args:
            config: Configuration dictionary (or None to load from environment)
        """
        self.config = config or self._load_config_from_env()
        self.db_connection = None
        self.nl2sql_engine = None
        self.query_executor = None
    
    def _load_config_from_env(self) -> Dict[str, Any]:
        """Load configuration from environment variables"""
        from dotenv import load_dotenv
        load_dotenv()
        
        return {
            # Model configuration
            "github_token": os.getenv("GITHUB_TOKEN"),
            "model_endpoint": os.getenv("MODEL_ENDPOINT", "https://models.github.ai/inference/"),
            "model_name": os.getenv("MODEL_NAME", "openai/gpt-4.1-mini"),
            
            # Database configuration
            "database_type": os.getenv("DATABASE_TYPE", "sqlite"),
            "database_path": os.getenv("DATABASE_PATH", "./sample_data.db"),
            "db_host": os.getenv("DB_HOST", "localhost"),
            "db_port": int(os.getenv("DB_PORT", "5432")),
            "db_name": os.getenv("DB_NAME", "postgres"),
            "db_user": os.getenv("DB_USER", "postgres"),
            "db_password": os.getenv("DB_PASSWORD", ""),
            
            # Security settings
            "allow_write_operations": os.getenv("ALLOW_WRITE_OPERATIONS", "false").lower() == "true",
            "max_result_rows": int(os.getenv("MAX_RESULT_ROWS", "100")),
            "query_timeout_seconds": int(os.getenv("QUERY_TIMEOUT_SECONDS", "30"))
        }
    
    def initialize(self) -> None:
        """Initialize all components"""
        print(f"{Fore.CYAN}🚀 Initializing NL2SQL Application...{Style.RESET_ALL}\n")
        
        # Initialize database connection
        from database import create_connection
        
        if self.config["database_type"] == "sqlite":
            self.db_connection = create_connection(
                "sqlite",
                database_path=self.config["database_path"]
            )
        elif self.config["database_type"] == "postgresql":
            self.db_connection = create_connection(
                "postgresql",
                host=self.config["db_host"],
                port=self.config["db_port"],
                database=self.config["db_name"],
                user=self.config["db_user"],
                password=self.config["db_password"]
            )
        elif self.config["database_type"] == "mysql":
            self.db_connection = create_connection(
                "mysql",
                host=self.config["db_host"],
                port=self.config["db_port"],
                database=self.config["db_name"],
                user=self.config["db_user"],
                password=self.config["db_password"]
            )
        elif self.config["database_type"] == "mssql":
            self.db_connection = create_connection(
                "mssql",
                host=self.config["db_host"],
                port=self.config["db_port"],
                database=self.config["db_name"],
                user=self.config["db_user"],
                password=self.config["db_password"]
            )
        else:
            raise ValueError(f"Unsupported database type: {self.config['database_type']}")
        
        self.db_connection.connect()
        print(f"{Fore.GREEN}✓ Connected to {self.config['database_type']} database{Style.RESET_ALL}")
        
        # Get schema information
        schema_dict = self.db_connection.get_schema_info()
        schema_info = SchemaInfo(
            tables=schema_dict["tables"],
            relationships=schema_dict["relationships"]
        )
        print(f"{Fore.GREEN}✓ Loaded schema: {len(schema_info.tables)} tables{Style.RESET_ALL}")
        
        # Initialize NL2SQL engine
        self.nl2sql_engine = NL2SQLEngine(
            schema_info=schema_info,
            api_key=self.config["github_token"],
            base_url=self.config["model_endpoint"],
            model_id=self.config["model_name"],
            allow_write_operations=self.config["allow_write_operations"]
        )
        print(f"{Fore.GREEN}✓ Initialized NL2SQL engine with model: {self.config['model_name']}{Style.RESET_ALL}")
        
        # Initialize query executor
        self.query_executor = QueryExecutor(
            db_connection=self.db_connection,
            nl2sql_engine=self.nl2sql_engine,
            max_result_rows=self.config["max_result_rows"],
            timeout_seconds=self.config["query_timeout_seconds"]
        )
        print(f"{Fore.GREEN}✓ Query executor ready{Style.RESET_ALL}\n")
        
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}✅ NL2SQL Application Ready!{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}\n")
    
    async def query(self, natural_language_query: str, auto_execute: bool = True) -> Dict[str, Any]:
        """
        Execute a natural language query.
        
        Args:
            natural_language_query: User's question
            auto_execute: Whether to automatically execute safe queries
            
        Returns:
            Query result dictionary
        """
        if not self.query_executor:
            raise RuntimeError("Application not initialized. Call initialize() first.")
        
        return await self.query_executor.execute_natural_language_query(
            natural_language_query,
            auto_execute=auto_execute
        )
    
    def shutdown(self) -> None:
        """Shutdown application and cleanup resources"""
        if self.db_connection:
            self.db_connection.disconnect()
        print(f"\n{Fore.CYAN}👋 NL2SQL Application shutdown complete{Style.RESET_ALL}")
