"""
Core NL2SQL Engine
Handles natural language to SQL translation with schema reasoning and intent detection.
"""
import os
import asyncio
from typing import Optional, Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import sqlparse
from openai import AsyncOpenAI
from agent_framework import ChatAgent
from agent_framework.openai import OpenAIChatClient


class QueryIntent(Enum):
    """Types of query intents"""
    FILTERING = "filtering"
    AGGREGATION = "aggregation"
    COMPARISON = "comparison"
    TREND = "trend"
    LOOKUP = "lookup"
    JOIN = "join"
    UNKNOWN = "unknown"


@dataclass
class SchemaInfo:
    """Database schema information"""
    tables: Dict[str, List[Dict[str, str]]]
    relationships: List[Dict[str, str]]
    
    def get_schema_prompt(self) -> str:
        """Generate schema description for LLM"""
        schema_text = "DATABASE SCHEMA:\n\n"
        
        for table_name, columns in self.tables.items():
            schema_text += f"Table: {table_name}\n"
            schema_text += "Columns:\n"
            for col in columns:
                schema_text += f"  - {col['name']} ({col['type']})"
                if col.get('primary_key'):
                    schema_text += " [PRIMARY KEY]"
                if col.get('foreign_key'):
                    schema_text += f" [FOREIGN KEY -> {col['foreign_key']}]"
                if col.get('nullable'):
                    schema_text += " [NULLABLE]"
                schema_text += "\n"
            schema_text += "\n"
        
        if self.relationships:
            schema_text += "RELATIONSHIPS:\n"
            for rel in self.relationships:
                schema_text += f"  - {rel['from_table']}.{rel['from_column']} -> {rel['to_table']}.{rel['to_column']}\n"
        
        return schema_text


@dataclass
class NL2SQLResult:
    """Result of NL2SQL translation"""
    sql: str
    explanation: str
    intent: QueryIntent
    is_safe: bool
    validation_messages: List[str]


class NL2SQLEngine:
    """
    Core Natural Language to SQL translation engine.
    Uses LLM with schema reasoning to generate safe, accurate SQL queries.
    """
    
    def __init__(
        self,
        schema_info: SchemaInfo,
        api_key: Optional[str] = None,
        base_url: str = "https://models.github.ai/inference",
        model_id: str = "openai/gpt-4.1-mini",
        allow_write_operations: bool = False
    ):
        """
        Initialize NL2SQL engine.
        
        Args:
            schema_info: Database schema information
            api_key: API key (GitHub token for GitHub models)
            base_url: Model endpoint URL
            model_id: Model identifier
            allow_write_operations: Whether to allow INSERT/UPDATE/DELETE queries
        """
        self.schema_info = schema_info
        self.allow_write_operations = allow_write_operations
        self.model_id = model_id
        
        # Initialize OpenAI client for GitHub models
        api_key = api_key or os.getenv("GITHUB_TOKEN")
        if not api_key:
            raise ValueError("API key required. Set GITHUB_TOKEN environment variable.")
        
        self.openai_client = AsyncOpenAI(
            base_url=base_url,
            api_key=api_key
        )
        
        # Create chat client and agent
        self.chat_client = OpenAIChatClient(
            async_client=self.openai_client,
            model_id=model_id
        )
        
        self.agent = ChatAgent(
            chat_client=self.chat_client,
            name="NL2SQLAgent",
            instructions=self._build_system_prompt()
        )
    
    def _build_system_prompt(self) -> str:
        """Build comprehensive system prompt for the agent"""
        return f"""You are a world-class SQL expert and database interface architect.
Your task is to translate natural language queries into accurate, safe, and optimized SQL.

{self.schema_info.get_schema_prompt()}

CRITICAL RULES:
1. ALWAYS generate syntactically correct SQL
2. Use explicit JOIN syntax (INNER JOIN, LEFT JOIN) - NEVER use implicit joins
3. Use table aliases for readability
4. Handle NULL values appropriately
5. Consider performance optimization
6. NEVER generate destructive queries (DROP, TRUNCATE) unless explicitly allowed
7. If the query is ambiguous, use schema context to make the best interpretation
8. Only use tables and columns that exist in the schema

{"WRITE OPERATIONS (INSERT, UPDATE, DELETE) ARE DISABLED" if not self.allow_write_operations else "WRITE OPERATIONS ARE ENABLED - USE WITH CAUTION"}

RESPONSE FORMAT:
You must respond in EXACTLY this format:

SQL:
```sql
[Your SQL query here]
```

EXPLANATION:
[Brief explanation of what the query does and how it maps to the user's question]

INTENT:
[One of: FILTERING, AGGREGATION, COMPARISON, TREND, LOOKUP, JOIN, UNKNOWN]

If the user's question cannot be answered with the available schema, explain why clearly."""
    
    async def translate(self, natural_language_query: str) -> NL2SQLResult:
        """
        Translate natural language to SQL.
        
        Args:
            natural_language_query: User's question in natural language
            
        Returns:
            NL2SQLResult with SQL, explanation, and validation info
        """
        try:
            # Get response from agent
            response_text = ""
            async for chunk in self.agent.run_stream(natural_language_query):
                if chunk.text:
                    response_text += chunk.text
            
            # Parse response
            sql, explanation, intent = self._parse_agent_response(response_text)
            
            # Validate SQL
            is_safe, validation_messages = self._validate_sql(sql)
            
            return NL2SQLResult(
                sql=sql,
                explanation=explanation,
                intent=intent,
                is_safe=is_safe,
                validation_messages=validation_messages
            )
            
        except Exception as e:
            return NL2SQLResult(
                sql="",
                explanation=f"Error during translation: {str(e)}",
                intent=QueryIntent.UNKNOWN,
                is_safe=False,
                validation_messages=[f"Translation error: {str(e)}"]
            )
    
    def _parse_agent_response(self, response: str) -> Tuple[str, str, QueryIntent]:
        """Parse the agent's response to extract SQL, explanation, and intent"""
        sql = ""
        explanation = ""
        intent = QueryIntent.UNKNOWN
        
        # Extract SQL
        if "```sql" in response:
            sql_start = response.find("```sql") + 6
            sql_end = response.find("```", sql_start)
            sql = response[sql_start:sql_end].strip()
        elif "SQL:" in response:
            lines = response.split("\n")
            in_sql = False
            sql_lines = []
            for line in lines:
                if "SQL:" in line:
                    in_sql = True
                    continue
                if in_sql and ("EXPLANATION:" in line or "INTENT:" in line):
                    break
                if in_sql:
                    sql_lines.append(line)
            sql = "\n".join(sql_lines).strip()
        
        # Extract explanation
        if "EXPLANATION:" in response:
            exp_start = response.find("EXPLANATION:") + 12
            exp_end = response.find("INTENT:", exp_start)
            if exp_end == -1:
                explanation = response[exp_start:].strip()
            else:
                explanation = response[exp_start:exp_end].strip()
        
        # Extract intent
        if "INTENT:" in response:
            intent_start = response.find("INTENT:") + 7
            intent_text = response[intent_start:].strip().split("\n")[0].strip().upper()
            try:
                intent = QueryIntent[intent_text]
            except KeyError:
                intent = QueryIntent.UNKNOWN
        
        return sql, explanation, intent
    
    def _validate_sql(self, sql: str) -> Tuple[bool, List[str]]:
        """
        Validate SQL for safety and correctness.
        
        Returns:
            Tuple of (is_safe, validation_messages)
        """
        messages = []
        is_safe = True
        
        if not sql:
            return False, ["No SQL query generated"]
        
        try:
            # Parse SQL
            parsed = sqlparse.parse(sql)
            if not parsed:
                return False, ["Invalid SQL syntax"]
            
            statement = parsed[0]
            sql_upper = sql.upper()
            
            # Check for destructive operations
            destructive_keywords = ["DROP", "TRUNCATE", "ALTER"]
            for keyword in destructive_keywords:
                if keyword in sql_upper:
                    is_safe = False
                    messages.append(f"BLOCKED: Destructive operation '{keyword}' not allowed")
            
            # Check for write operations if disabled
            if not self.allow_write_operations:
                write_keywords = ["INSERT", "UPDATE", "DELETE"]
                for keyword in write_keywords:
                    if keyword in sql_upper:
                        is_safe = False
                        messages.append(f"BLOCKED: Write operation '{keyword}' not allowed")
            
            # Check for SQL injection patterns
            dangerous_patterns = ["--", ";DROP", ";DELETE", "EXEC(", "EXECUTE("]
            for pattern in dangerous_patterns:
                if pattern in sql_upper:
                    is_safe = False
                    messages.append(f"BLOCKED: Potential SQL injection pattern detected: {pattern}")
            
            # Validate table names exist in schema
            tokens = [token for token in statement.flatten() if token.ttype is None]
            for token in tokens:
                token_str = str(token).strip()
                if token_str and not token_str.startswith("("):
                    # This is a simplified check - could be enhanced
                    pass
            
            if is_safe and not messages:
                messages.append("SQL validation passed")
            
        except Exception as e:
            is_safe = False
            messages.append(f"Validation error: {str(e)}")
        
        return is_safe, messages
    
    def format_sql(self, sql: str) -> str:
        """Format SQL for better readability"""
        return sqlparse.format(
            sql,
            reindent=True,
            keyword_case='upper',
            identifier_case='lower',
            strip_comments=False
        )
