"""
Interactive CLI for NL2SQL Application
"""
import asyncio
import sys
from typing import Optional
from colorama import Fore, Style, init

from query_executor import NL2SQLApp

# Initialize colorama
init(autoreset=True)


class NL2SQLCLI:
    """Interactive command-line interface for NL2SQL"""
    
    def __init__(self):
        self.app = NL2SQLApp()
        self.running = False
    
    def print_banner(self):
        """Print application banner"""
        banner = f"""
{Fore.CYAN}{'='*70}
{Style.BRIGHT}  _   _ _     ____  ____   ___  _     
 | \ | | |   |___ \/ ___| / _ \| |    
 |  \| | |     __) \___ \| | | | |    
 | |\  | |___ / __/ ___) | |_| | |___ 
 |_| \_|_____|_____|____/ \___/|_____|
                                       
        🚀 Natural Language to SQL Interface 🚀
{Fore.CYAN}{'='*70}{Style.RESET_ALL}

{Fore.YELLOW}Transform your questions into powerful SQL queries!{Style.RESET_ALL}

{Fore.WHITE}Type your questions in plain English and get instant SQL results.
Type 'help' for commands, 'examples' for sample queries, or 'exit' to quit.{Style.RESET_ALL}
{Fore.CYAN}{'='*70}{Style.RESET_ALL}
"""
        print(banner)
    
    def print_help(self):
        """Print help information"""
        help_text = f"""
{Fore.CYAN}{'='*70}
{Style.BRIGHT}Available Commands{Style.RESET_ALL}
{Fore.CYAN}{'='*70}{Style.RESET_ALL}

{Fore.GREEN}help{Style.RESET_ALL}        - Show this help message
{Fore.GREEN}examples{Style.RESET_ALL}    - Show example queries
{Fore.GREEN}schema{Style.RESET_ALL}      - Display database schema
{Fore.GREEN}clear{Style.RESET_ALL}       - Clear the screen
{Fore.GREEN}exit{Style.RESET_ALL}        - Exit the application

{Fore.YELLOW}Query Tips:{Style.RESET_ALL}
- Be specific about what you want to find
- Mention table names if you know them
- Use natural comparisons like "greater than", "more than", "less than"
- For aggregations, use words like "total", "average", "count"
- For sorting, use "top", "highest", "lowest", "order by"

{Fore.CYAN}{'='*70}{Style.RESET_ALL}
"""
        print(help_text)
    
    def print_examples(self):
        """Print example queries"""
        examples = f"""
{Fore.CYAN}{'='*70}
{Style.BRIGHT}Example Queries{Style.RESET_ALL}
{Fore.CYAN}{'='*70}{Style.RESET_ALL}

{Fore.GREEN}Simple Filtering:{Style.RESET_ALL}
  • "Show me all customers from Germany"
  • "Find all orders placed in 2024"
  • "List products with price greater than 100"

{Fore.GREEN}Aggregation:{Style.RESET_ALL}
  • "What is the total revenue for each customer?"
  • "How many orders were placed last month?"
  • "What's the average product price?"

{Fore.GREEN}Joining Tables:{Style.RESET_ALL}
  • "Show customer names with their orders"
  • "List products sold in each order"
  • "Find customers who haven't placed any orders"

{Fore.GREEN}Sorting & Limiting:{Style.RESET_ALL}
  • "Show top 10 customers by total revenue"
  • "Find the 5 most expensive products"
  • "List recent orders, newest first"

{Fore.GREEN}Comparisons:{Style.RESET_ALL}
  • "Which products are more expensive than the average?"
  • "Show customers with more than 5 orders"
  • "Find orders with total greater than $1000"

{Fore.CYAN}{'='*70}{Style.RESET_ALL}
"""
        print(examples)
    
    def print_schema(self):
        """Print database schema"""
        if not self.app.nl2sql_engine:
            print(f"{Fore.RED}Error: Application not initialized{Style.RESET_ALL}")
            return
        
        schema_info = self.app.nl2sql_engine.schema_info
        
        print(f"\n{Fore.CYAN}{'='*70}")
        print(f"{Style.BRIGHT}Database Schema{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*70}{Style.RESET_ALL}\n")
        
        for table_name, columns in schema_info.tables.items():
            print(f"{Fore.GREEN}📋 Table: {Style.BRIGHT}{table_name}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Columns:{Style.RESET_ALL}")
            
            for col in columns:
                col_str = f"  • {col['name']} ({col['type']})"
                if col.get('primary_key'):
                    col_str += f" {Fore.YELLOW}[PK]{Style.RESET_ALL}"
                if col.get('foreign_key'):
                    col_str += f" {Fore.CYAN}[FK → {col['foreign_key']}]{Style.RESET_ALL}"
                if col.get('nullable'):
                    col_str += f" {Fore.WHITE}[NULL]{Style.RESET_ALL}"
                print(col_str)
            print()
        
        if schema_info.relationships:
            print(f"{Fore.MAGENTA}🔗 Relationships:{Style.RESET_ALL}")
            for rel in schema_info.relationships:
                print(f"  • {rel['from_table']}.{rel['from_column']} → {rel['to_table']}.{rel['to_column']}")
            print()
        
        print(f"{Fore.CYAN}{'='*70}{Style.RESET_ALL}\n")
    
    async def run(self):
        """Run the interactive CLI"""
        self.running = True
        
        try:
            # Print banner
            self.print_banner()
            
            # Initialize application
            self.app.initialize()
            
            # Main loop
            while self.running:
                try:
                    # Get user input
                    user_input = input(f"{Fore.YELLOW}💬 Your question: {Style.RESET_ALL}").strip()
                    
                    if not user_input:
                        continue
                    
                    # Handle commands
                    if user_input.lower() in ['exit', 'quit', 'q']:
                        print(f"\n{Fore.CYAN}Goodbye! 👋{Style.RESET_ALL}\n")
                        self.running = False
                        break
                    
                    elif user_input.lower() == 'help':
                        self.print_help()
                        continue
                    
                    elif user_input.lower() == 'examples':
                        self.print_examples()
                        continue
                    
                    elif user_input.lower() == 'schema':
                        self.print_schema()
                        continue
                    
                    elif user_input.lower() == 'clear':
                        import os
                        os.system('cls' if os.name == 'nt' else 'clear')
                        self.print_banner()
                        continue
                    
                    # Execute query
                    await self.app.query(user_input, auto_execute=True)
                    
                except KeyboardInterrupt:
                    print(f"\n{Fore.YELLOW}Use 'exit' to quit{Style.RESET_ALL}")
                    continue
                
                except Exception as e:
                    print(f"{Fore.RED}❌ Error: {str(e)}{Style.RESET_ALL}\n")
                    continue
        
        finally:
            # Cleanup
            self.app.shutdown()


async def main():
    """Main entry point"""
    try:
        cli = NL2SQLCLI()
        await cli.run()
    except KeyboardInterrupt:
        print(f"\n{Fore.CYAN}Application interrupted{Style.RESET_ALL}\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Fore.RED}Fatal error: {str(e)}{Style.RESET_ALL}\n")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
