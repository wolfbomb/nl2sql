"""
Sample Database Setup
Creates a sample e-commerce database with test data for demonstration.
"""
import sqlite3
import os
from datetime import datetime, timedelta
import random


def create_sample_database(db_path: str = "sample_data.db"):
    """
    Create a sample e-commerce database with customers, products, orders, and order_items.
    
    Args:
        db_path: Path to the SQLite database file
    """
    # Remove existing database
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"Removed existing database: {db_path}")
    
    # Create connection
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("Creating sample database...")
    
    # Create tables
    cursor.executescript("""
        -- Customers table
        CREATE TABLE customers (
            customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            country TEXT NOT NULL,
            city TEXT NOT NULL,
            registration_date DATE NOT NULL
        );
        
        -- Products table
        CREATE TABLE products (
            product_id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            category TEXT NOT NULL,
            price DECIMAL(10, 2) NOT NULL,
            stock_quantity INTEGER NOT NULL,
            supplier TEXT NOT NULL
        );
        
        -- Orders table
        CREATE TABLE orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            order_date DATE NOT NULL,
            status TEXT NOT NULL,
            total_amount DECIMAL(10, 2) NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        );
        
        -- Order Items table
        CREATE TABLE order_items (
            order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price DECIMAL(10, 2) NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(order_id),
            FOREIGN KEY (product_id) REFERENCES products(product_id)
        );
    """)
    
    print("✓ Tables created")
    
    # Insert sample customers
    customers_data = [
        ("John", "Doe", "john.doe@email.com", "USA", "New York", "2023-01-15"),
        ("Jane", "Smith", "jane.smith@email.com", "UK", "London", "2023-02-20"),
        ("Michael", "Johnson", "michael.j@email.com", "Canada", "Toronto", "2023-03-10"),
        ("Emma", "Brown", "emma.brown@email.com", "Germany", "Berlin", "2023-04-05"),
        ("Oliver", "Davis", "oliver.d@email.com", "France", "Paris", "2023-05-12"),
        ("Sophia", "Wilson", "sophia.w@email.com", "USA", "Los Angeles", "2023-06-18"),
        ("James", "Martinez", "james.m@email.com", "Spain", "Madrid", "2023-07-22"),
        ("Ava", "Garcia", "ava.garcia@email.com", "Italy", "Rome", "2023-08-30"),
        ("William", "Lopez", "william.l@email.com", "Australia", "Sydney", "2023-09-14"),
        ("Isabella", "Lee", "isabella.lee@email.com", "Japan", "Tokyo", "2023-10-25"),
    ]
    
    cursor.executemany(
        "INSERT INTO customers (first_name, last_name, email, country, city, registration_date) VALUES (?, ?, ?, ?, ?, ?)",
        customers_data
    )
    print(f"✓ Inserted {len(customers_data)} customers")
    
    # Insert sample products
    products_data = [
        ("Laptop Pro 15", "Electronics", 1299.99, 50, "Tech Supply Co"),
        ("Wireless Mouse", "Electronics", 29.99, 200, "Tech Supply Co"),
        ("USB-C Cable", "Electronics", 12.99, 500, "Cable World"),
        ("Office Chair", "Furniture", 249.99, 30, "Furniture Plus"),
        ("Standing Desk", "Furniture", 599.99, 20, "Furniture Plus"),
        ("LED Monitor 27", "Electronics", 349.99, 75, "Display Tech"),
        ("Mechanical Keyboard", "Electronics", 89.99, 100, "Tech Supply Co"),
        ("Desk Lamp", "Furniture", 39.99, 150, "Light & Co"),
        ("Webcam HD", "Electronics", 79.99, 80, "Tech Supply Co"),
        ("Headphones Pro", "Electronics", 199.99, 60, "Audio Masters"),
        ("Notebook Set", "Stationery", 15.99, 300, "Paper Works"),
        ("Pen Collection", "Stationery", 9.99, 400, "Paper Works"),
        ("Coffee Maker", "Appliances", 89.99, 45, "Kitchen Pro"),
        ("Water Bottle", "Accessories", 19.99, 250, "Sports Gear"),
        ("Backpack", "Accessories", 49.99, 120, "Travel Essentials"),
    ]
    
    cursor.executemany(
        "INSERT INTO products (product_name, category, price, stock_quantity, supplier) VALUES (?, ?, ?, ?, ?)",
        products_data
    )
    print(f"✓ Inserted {len(products_data)} products")
    
    # Generate sample orders
    order_statuses = ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]
    start_date = datetime(2024, 1, 1)
    
    orders_data = []
    order_items_data = []
    order_id = 1
    
    for _ in range(50):
        customer_id = random.randint(1, 10)
        order_date = start_date + timedelta(days=random.randint(0, 350))
        status = random.choice(order_statuses)
        
        # Generate 1-4 items per order
        num_items = random.randint(1, 4)
        total_amount = 0
        
        for _ in range(num_items):
            product_id = random.randint(1, 15)
            quantity = random.randint(1, 3)
            
            # Get product price (we'll use the products_data list)
            unit_price = products_data[product_id - 1][2]
            total_amount += unit_price * quantity
            
            order_items_data.append((
                order_id,
                product_id,
                quantity,
                unit_price
            ))
        
        orders_data.append((
            customer_id,
            order_date.strftime("%Y-%m-%d"),
            status,
            total_amount
        ))
        
        order_id += 1
    
    cursor.executemany(
        "INSERT INTO orders (customer_id, order_date, status, total_amount) VALUES (?, ?, ?, ?)",
        orders_data
    )
    print(f"✓ Inserted {len(orders_data)} orders")
    
    cursor.executemany(
        "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
        order_items_data
    )
    print(f"✓ Inserted {len(order_items_data)} order items")
    
    # Commit and close
    conn.commit()
    conn.close()
    
    print(f"\n✅ Sample database created successfully: {db_path}")
    print("\nDatabase contains:")
    print("  • 10 customers from different countries")
    print("  • 15 products across multiple categories")
    print("  • 50 orders with various statuses")
    print(f"  • {len(order_items_data)} order items")
    print("\nReady to use with NL2SQL application!")


if __name__ == "__main__":
    create_sample_database()
