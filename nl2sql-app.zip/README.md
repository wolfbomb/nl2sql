# 🚀 NL2SQL - Natural Language to SQL Interface

A production-grade application that transforms natural language queries into accurate, safe, and optimized SQL using advanced AI reasoning and database schema intelligence.

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

### 🎯 Core Capabilities
- **Natural Language Understanding**: Translate plain English questions into SQL queries
- **Multi-Database Support**: Works with SQLite, PostgreSQL, MySQL, and MSSQL
- **Schema-Aware Reasoning**: Automatically understands your database structure
- **Intent Detection**: Identifies query types (filtering, aggregation, joins, etc.)
- **Safety First**: Prevents destructive operations and SQL injection attacks
- **Explainable AI**: Shows how natural language maps to SQL

### 🔒 Security Features
- SQL injection prevention
- Configurable write operation blocking
- Query validation before execution
- Result limiting to prevent overload
- Timeout protection

### 🎨 User Experience
- Interactive CLI with colored output
- Real-time query translation
- Beautiful table formatting for results
- Built-in examples and help system
- Schema visualization

## 📋 Table of Contents

- [Architecture](#architecture)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Usage Examples](#usage-examples)
- [API Reference](#api-reference)
- [Advanced Features](#advanced-features)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     User Interface Layer                     │
│  • Interactive CLI                                            │
│  • Command Processing                                         │
└───────────────────────┬─────────────────────────────────────┘
                        │
┌───────────────────────▼─────────────────────────────────────┐
│              Query Executor & Orchestration                  │
│  • Query Coordination  • Result Formatting                   │
│  • Timeout Management  • Error Handling                      │
└───────────────────────┬─────────────────────────────────────┘
                        │
        ┌───────────────┴────────────────┐
        │                                │
┌───────▼──────────┐          ┌─────────▼────────┐
│  NL2SQL Engine   │          │  Database Layer  │
│  • LLM Agent     │          │  • Connections   │
│  • Schema Reason │◄─────────┤  • Schema Info   │
│  • SQL Generate  │          │  • Query Exec    │
│  • Validation    │          │  • Multi-DB      │
└──────────────────┘          └──────────────────┘
        │
┌───────▼──────────────────────────────────────────┐
│        Microsoft Agent Framework                  │
│  • GitHub Models (gpt-4.1-mini)                  │
│  • OpenAI API Compatible                         │
└──────────────────────────────────────────────────┘
```

### System Components

#### 1. **NL2SQL Engine** (`nl2sql_engine.py`)
The core AI component that translates natural language to SQL:
- **Schema Reasoning**: Understands database structure and relationships
- **Intent Detection**: Identifies query purpose (filtering, aggregation, etc.)
- **SQL Generation**: Creates optimized, safe SQL using LLM
- **Validation**: Ensures query safety before execution

#### 2. **Database Layer** (`database.py`)
Provides unified interface for multiple database types:
- **Connection Management**: SQLite, PostgreSQL, MySQL, MSSQL support
- **Schema Introspection**: Automatic discovery of tables, columns, relationships
- **Query Execution**: Safe, timeout-protected query execution

#### 3. **Query Executor** (`query_executor.py`)
Orchestrates the query lifecycle:
- **Translation Coordination**: Manages NL to SQL conversion
- **Execution Control**: Handles query execution with safety checks
- **Result Formatting**: Beautiful output with tables and statistics

#### 4. **CLI Interface** (`cli.py`)
Interactive user experience:
- **Command Processing**: Handles user input and commands
- **Visual Feedback**: Colored, formatted output
- **Help System**: Built-in documentation and examples

## 🚀 Installation

### Prerequisites
- Python 3.8 or higher
- GitHub Personal Access Token (for GitHub Models)

### Step 1: Clone or Download

```bash
cd C:/nl2sql-app
```

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

**Note**: The `--pre` flag is required for `agent-framework-azure-ai` as it's currently in preview.

### Step 3: Configure Environment

Create a `.env` file from the example:

```bash
copy .env.example .env
```

Edit `.env` and add your GitHub Personal Access Token:

```env
GITHUB_TOKEN=ghp_your_github_personal_access_token_here
```

**Get your GitHub token**: Visit [GitHub Settings > Developer Settings > Personal Access Tokens](https://github.com/settings/tokens)

### Step 4: Create Sample Database

```bash
python create_sample_db.py
```

This creates a sample e-commerce database with customers, products, and orders.

## ⚡ Quick Start

### Run the Interactive CLI

```bash
cd src
python cli.py
```

You'll see:

```
======================================================================
  _   _ _     ____  ____   ___  _     
 | \ | | |   |___ \/ ___| / _ \| |    
 |  \| | |     __) \___ \| | | | |    
 | |\  | |___ / __/ ___) | |_| | |___ 
 |_| \_|_____|_____|____/ \___/|_____|
                                       
        🚀 Natural Language to SQL Interface 🚀
======================================================================

🚀 Initializing NL2SQL Application...
✓ Connected to sqlite database
✓ Loaded schema: 4 tables
✓ Initialized NL2SQL engine with model: openai/gpt-4.1-mini
✓ Query executor ready

============================================================
✅ NL2SQL Application Ready!
============================================================

💬 Your question: 
```

### Try Some Queries

```
💬 Your question: Show me all customers from Germany

🤔 Processing: Show me all customers from Germany
⏳ Translating to SQL...

📝 Generated SQL:
SELECT *
FROM customers
WHERE country = 'Germany';

💡 Explanation:
This query retrieves all customer records where the country is 'Germany'.

🎯 Query Intent: FILTERING

⚠️  Validation:
  ✓ SQL validation passed

✅ Query is safe. Executing...

📊 Results (1 rows in 0.003s):
╒═══════════════╤══════════════╤═════════════╤═════════════════════════╤═══════════╤═════════╤═════════════════════╕
│   customer_id │ first_name   │ last_name   │ email                   │ country   │ city    │ registration_date   │
╞═══════════════╪══════════════╪═════════════╪═════════════════════════╪═══════════╪═════════╪═════════════════════╡
│             4 │ Emma         │ Brown       │ emma.brown@email.com    │ Germany   │ Berlin  │ 2023-04-05          │
╘═══════════════╧══════════════╧═════════════╧═════════════════════════╧═══════════╧═════════╧═════════════════════╛
```

### Available Commands

- `help` - Show available commands
- `examples` - Display example queries
- `schema` - View database structure
- `clear` - Clear screen
- `exit` - Quit application

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `GITHUB_TOKEN` | Your GitHub Personal Access Token | **Required** |
| `MODEL_NAME` | Model to use for translation | `openai/gpt-4.1-mini` |
| `MODEL_ENDPOINT` | API endpoint URL | `https://models.github.ai/inference/` |
| `DATABASE_TYPE` | Database type (sqlite/postgresql/mysql/mssql) | `sqlite` |
| `DATABASE_PATH` | Path to SQLite database | `./sample_data.db` |
| `ALLOW_WRITE_OPERATIONS` | Enable INSERT/UPDATE/DELETE | `false` |
| `MAX_RESULT_ROWS` | Maximum rows to return | `100` |
| `QUERY_TIMEOUT_SECONDS` | Query timeout | `30` |

### Database Configuration

#### SQLite (Default)
```env
DATABASE_TYPE=sqlite
DATABASE_PATH=./sample_data.db
```

#### PostgreSQL
```env
DATABASE_TYPE=postgresql
DB_HOST=localhost
DB_PORT=5432
DB_NAME=your_database
DB_USER=your_username
DB_PASSWORD=your_password
```

#### MySQL
```env
DATABASE_TYPE=mysql
DB_HOST=localhost
DB_PORT=3306
DB_NAME=your_database
DB_USER=your_username
DB_PASSWORD=your_password
```

#### Microsoft SQL Server
```env
DATABASE_TYPE=mssql
DB_HOST=localhost
DB_PORT=1433
DB_NAME=your_database
DB_USER=your_username
DB_PASSWORD=your_password
```

### Model Selection

The application uses GitHub Models with free tier access:

**Recommended Models:**
- `openai/gpt-4.1-mini` - Best balance of cost/performance (default)
- `openai/gpt-4.1` - Higher accuracy for complex queries
- `openai/o1-mini` - Advanced reasoning capabilities

**Why GitHub Models?**
- ✅ Free tier available (rate-limited)
- ✅ Single API key for all models
- ✅ Easy to switch between models
- ✅ Production-ready infrastructure

## 📚 Usage Examples

### Simple Filtering

```
💬 Show me all customers from Germany
💬 Find products with price greater than 100
💬 List orders placed in December 2024
```

### Aggregations

```
💬 What is the total revenue by customer?
💬 How many orders were placed last month?
💬 What's the average product price by category?
💬 Count customers from each country
```

### Joins

```
💬 Show customer names with their orders
💬 List all products in order #12345
💬 Find customers who haven't placed any orders
💬 Which products were ordered by John Doe?
```

### Sorting & Limiting

```
💬 Show top 10 customers by total spending
💬 Find the 5 most expensive products
💬 List recent orders, newest first
💬 What are the bottom 3 products by sales?
```

### Complex Queries

```
💬 Which products are more expensive than average?
💬 Show customers with more than 5 orders
💬 Find orders with total greater than $1000
💬 What's the revenue trend by month for 2024?
```

### Analytical Queries

```
💬 Compare sales by quarter
💬 What percentage of orders are delivered?
💬 Show inventory levels below 50 units
💬 Calculate order fulfillment rate by status
```

## 🔧 API Reference

### Programmatic Usage

You can use NL2SQL in your Python code:

```python
import asyncio
from query_executor import NL2SQLApp

async def main():
    # Initialize application
    app = NL2SQLApp()
    app.initialize()
    
    # Execute query
    result = await app.query(
        "Show me all customers from Germany",
        auto_execute=True
    )
    
    # Access results
    if result['result']:
        print(f"Found {result['result'].row_count} rows")
        for row in result['result'].rows:
            print(row)
    
    # Cleanup
    app.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
```

### NL2SQLEngine Class

```python
from nl2sql_engine import NL2SQLEngine, SchemaInfo

# Create schema info
schema = SchemaInfo(
    tables={
        "customers": [
            {"name": "customer_id", "type": "INTEGER", "primary_key": True},
            {"name": "name", "type": "TEXT", "nullable": False}
        ]
    },
    relationships=[]
)

# Initialize engine
engine = NL2SQLEngine(
    schema_info=schema,
    api_key="your_github_token",
    model_id="openai/gpt-4.1-mini",
    allow_write_operations=False
)

# Translate query
result = await engine.translate("Show all customers")
print(result.sql)
print(result.explanation)
```

### DatabaseConnection Class

```python
from database import create_connection

# Create connection
db = create_connection(
    "sqlite",
    database_path="./sample_data.db"
)

db.connect()

# Get schema
schema = db.get_schema_info()
print(schema)

# Execute query
result = db.execute_query("SELECT * FROM customers LIMIT 5")
print(result.rows)

db.disconnect()
```

## 🎓 Advanced Features

### Chain of Thought Reasoning

The NL2SQL engine follows a sophisticated reasoning process:

1. **UNDERSTAND**: Parse user intent and identify query type
2. **BASICS**: Identify SQL concepts needed (SELECT, JOIN, etc.)
3. **BREAK DOWN**: Map natural language terms to database entities
4. **ANALYZE**: Resolve ambiguity using schema context
5. **BUILD**: Generate optimized SQL step-by-step
6. **EDGE CASES**: Handle NULL values, missing data
7. **VALIDATE**: Safety checks before execution

### SQL Safety Validation

Automatic blocking of:
- Destructive operations (DROP, TRUNCATE, ALTER)
- Configurable write operations (INSERT, UPDATE, DELETE)
- SQL injection patterns
- Suspicious command sequences

### Schema Intelligence

The system automatically:
- Discovers all tables and columns
- Identifies primary and foreign keys
- Maps relationships between tables
- Understands data types and constraints
- Uses this context for accurate SQL generation

### Performance Optimization

- Query timeout protection
- Result set limiting
- Efficient schema caching
- Optimized SQL formatting

## 🐛 Troubleshooting

### Common Issues

#### "API key required" Error
**Solution**: Make sure your `.env` file contains a valid `GITHUB_TOKEN`:
```env
GITHUB_TOKEN=ghp_your_actual_token_here
```

#### Rate Limit Errors
**Solution**: GitHub Models free tier has rate limits. Wait a few minutes or upgrade to paid tier.

#### Database Connection Failed
**Solution**: Check database credentials in `.env`. For SQLite, ensure the file path is correct.

#### Module Not Found Errors
**Solution**: Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```
**Remember**: Use `pip install agent-framework-azure-ai --pre` for the agent framework.

#### Query Not Executing
**Solution**: 
- Check if query is blocked by safety validation
- Ensure `ALLOW_WRITE_OPERATIONS=true` if trying INSERT/UPDATE/DELETE
- Review validation messages in output

### Enable Debug Logging

Add to your code:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 🌟 Best Practices

### Writing Effective Natural Language Queries

✅ **DO:**
- Be specific about what you want to find
- Mention table names if you know them
- Use natural comparisons ("greater than", "more than")
- Specify sorting/limiting clearly

❌ **DON'T:**
- Use ambiguous terms
- Mix multiple unrelated questions
- Assume implicit context

### Security Recommendations

1. **Never expose API keys** - Use environment variables
2. **Disable write operations** in production unless needed
3. **Set appropriate result limits** to prevent resource exhaustion
4. **Use read-only database users** when possible
5. **Review generated SQL** before allowing execution in critical systems

### Performance Tips

1. **Add indexes** to frequently queried columns
2. **Limit result sets** using specific criteria
3. **Use connection pooling** for high-volume applications
4. **Cache schema information** when possible
5. **Monitor query execution times**

## 🤝 Contributing

Contributions are welcome! Areas for improvement:

- Additional database support (Oracle, DB2, etc.)
- Query optimization analysis
- Multi-language support
- Web UI interface
- Query history and favorites
- Advanced analytics features

## 📄 License

MIT License - feel free to use in your projects!

## 🙏 Acknowledgments

- **Microsoft Agent Framework** - Powerful agent orchestration
- **GitHub Models** - Free-tier AI model access
- **OpenAI** - GPT model architecture
- **SQLParse** - SQL parsing and formatting

## 📞 Support

- GitHub Issues: Report bugs and request features
- Documentation: This README
- Examples: See `examples` directory

---

**Built with ❤️ using Microsoft Agent Framework and GitHub Models**

*Transform your questions into powerful SQL queries - No SQL expertise required!*
