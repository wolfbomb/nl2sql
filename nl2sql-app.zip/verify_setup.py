"""
Setup Verification Script
Checks if your NL2SQL installation is configured correctly.
"""
import sys
import os
from colorama import Fore, Style, init

init(autoreset=True)


def print_header(text):
    """Print a formatted header"""
    print(f"\n{Fore.CYAN}{'=' * 70}")
    print(f"{Style.BRIGHT}{text}")
    print(f"{Fore.CYAN}{'=' * 70}{Style.RESET_ALL}\n")


def check_python_version():
    """Check if Python version is sufficient"""
    print(f"{Fore.YELLOW}Checking Python version...{Style.RESET_ALL}")
    version = sys.version_info
    
    if version.major >= 3 and version.minor >= 8:
        print(f"{Fore.GREEN}✓ Python {version.major}.{version.minor}.{version.micro} - OK{Style.RESET_ALL}")
        return True
    else:
        print(f"{Fore.RED}✗ Python {version.major}.{version.minor}.{version.micro} - FAILED{Style.RESET_ALL}")
        print(f"{Fore.RED}  Python 3.8 or higher required{Style.RESET_ALL}")
        return False


def check_dependencies():
    """Check if required packages are installed"""
    print(f"\n{Fore.YELLOW}Checking dependencies...{Style.RESET_ALL}")
    
    required_packages = [
        ("agent_framework", "agent-framework-azure-ai"),
        ("openai", "openai"),
        ("sqlparse", "sqlparse"),
        ("dotenv", "python-dotenv"),
        ("tabulate", "tabulate"),
        ("colorama", "colorama"),
        ("pydantic", "pydantic")
    ]
    
    all_ok = True
    for module_name, package_name in required_packages:
        try:
            __import__(module_name)
            print(f"{Fore.GREEN}✓ {package_name:30} - Installed{Style.RESET_ALL}")
        except ImportError:
            print(f"{Fore.RED}✗ {package_name:30} - Missing{Style.RESET_ALL}")
            all_ok = False
    
    if not all_ok:
        print(f"\n{Fore.YELLOW}To install missing packages, run:{Style.RESET_ALL}")
        print(f"{Fore.WHITE}pip install -r requirements.txt{Style.RESET_ALL}")
    
    return all_ok


def check_env_file():
    """Check if .env file exists and is configured"""
    print(f"\n{Fore.YELLOW}Checking environment configuration...{Style.RESET_ALL}")
    
    if not os.path.exists(".env"):
        print(f"{Fore.RED}✗ .env file not found{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  Create .env file from .env.example:{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  copy .env.example .env{Style.RESET_ALL}")
        return False
    
    print(f"{Fore.GREEN}✓ .env file exists{Style.RESET_ALL}")
    
    # Check if GITHUB_TOKEN is set
    from dotenv import load_dotenv
    load_dotenv()
    
    github_token = os.getenv("GITHUB_TOKEN")
    
    if not github_token or github_token.startswith("ghp_your_"):
        print(f"{Fore.RED}✗ GITHUB_TOKEN not configured{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  Add your GitHub token to .env file{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  Get token from: https://github.com/settings/tokens{Style.RESET_ALL}")
        return False
    
    print(f"{Fore.GREEN}✓ GITHUB_TOKEN is configured{Style.RESET_ALL}")
    return True


def check_database():
    """Check if sample database exists"""
    print(f"\n{Fore.YELLOW}Checking database...{Style.RESET_ALL}")
    
    from dotenv import load_dotenv
    load_dotenv()
    
    db_type = os.getenv("DATABASE_TYPE", "sqlite")
    
    if db_type == "sqlite":
        db_path = os.getenv("DATABASE_PATH", "./sample_data.db")
        
        if not os.path.exists(db_path):
            print(f"{Fore.RED}✗ Database file not found: {db_path}{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}  Create sample database:{Style.RESET_ALL}")
            print(f"{Fore.WHITE}  python create_sample_db.py{Style.RESET_ALL}")
            return False
        
        print(f"{Fore.GREEN}✓ Database file exists: {db_path}{Style.RESET_ALL}")
        
        # Check if database has tables
        import sqlite3
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        conn.close()
        
        if len(tables) == 0:
            print(f"{Fore.RED}✗ Database is empty{Style.RESET_ALL}")
            return False
        
        print(f"{Fore.GREEN}✓ Database has {len(tables)} tables{Style.RESET_ALL}")
        return True
    else:
        print(f"{Fore.YELLOW}⚠ Using {db_type} database - cannot verify automatically{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  Make sure your database credentials are correct in .env{Style.RESET_ALL}")
        return True


def check_project_structure():
    """Check if all required files exist"""
    print(f"\n{Fore.YELLOW}Checking project structure...{Style.RESET_ALL}")
    
    required_files = [
        "requirements.txt",
        ".env.example",
        ".gitignore",
        "README.md",
        "QUICKSTART.md",
        "create_sample_db.py",
        "examples.py",
        "src/__init__.py",
        "src/nl2sql_engine.py",
        "src/database.py",
        "src/query_executor.py",
        "src/cli.py"
    ]
    
    all_exist = True
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"{Fore.GREEN}✓ {file_path}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}✗ {file_path} - Missing{Style.RESET_ALL}")
            all_exist = False
    
    return all_exist


def test_connection():
    """Test connection to GitHub Models API"""
    print(f"\n{Fore.YELLOW}Testing API connection...{Style.RESET_ALL}")
    
    try:
        from dotenv import load_dotenv
        load_dotenv()
        
        github_token = os.getenv("GITHUB_TOKEN")
        if not github_token or github_token.startswith("ghp_your_"):
            print(f"{Fore.RED}✗ Cannot test - GITHUB_TOKEN not configured{Style.RESET_ALL}")
            return False
        
        from openai import OpenAI
        
        client = OpenAI(
            base_url="https://models.github.ai/inference/",
            api_key=github_token
        )
        
        # Try a simple API call
        response = client.chat.completions.create(
            model="openai/gpt-4.1-mini",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=10
        )
        
        print(f"{Fore.GREEN}✓ API connection successful{Style.RESET_ALL}")
        print(f"{Fore.GREEN}✓ Model responded: {response.choices[0].message.content[:50]}...{Style.RESET_ALL}")
        return True
        
    except Exception as e:
        print(f"{Fore.RED}✗ API connection failed: {str(e)}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  Check your GITHUB_TOKEN and internet connection{Style.RESET_ALL}")
        return False


def main():
    """Run all verification checks"""
    print_header("🔍 NL2SQL Setup Verification")
    
    print(f"{Fore.CYAN}This script will verify your installation is ready to use.{Style.RESET_ALL}\n")
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("Environment Config", check_env_file),
        ("Database", check_database),
        ("Project Structure", check_project_structure),
        ("API Connection", test_connection)
    ]
    
    results = {}
    
    for check_name, check_func in checks:
        try:
            results[check_name] = check_func()
        except Exception as e:
            print(f"{Fore.RED}✗ {check_name} check failed with error: {str(e)}{Style.RESET_ALL}")
            results[check_name] = False
    
    # Print summary
    print_header("📊 Verification Summary")
    
    all_passed = True
    for check_name, passed in results.items():
        if passed:
            print(f"{Fore.GREEN}✓ {check_name:25} - PASSED{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}✗ {check_name:25} - FAILED{Style.RESET_ALL}")
            all_passed = False
    
    print()
    
    if all_passed:
        print(f"{Fore.GREEN}{Style.BRIGHT}🎉 All checks passed! You're ready to use NL2SQL!{Style.RESET_ALL}\n")
        print(f"{Fore.CYAN}Next steps:{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  1. Start the CLI: cd src && python cli.py{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  2. Try example queries: Show me all customers from Germany{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  3. Check examples.py for programmatic usage{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  4. Read QUICKSTART.md for detailed guide{Style.RESET_ALL}\n")
        return 0
    else:
        print(f"{Fore.YELLOW}{Style.BRIGHT}⚠️  Some checks failed. Please fix the issues above.{Style.RESET_ALL}\n")
        print(f"{Fore.CYAN}Need help?{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  • Check QUICKSTART.md for setup instructions{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  • Read README.md for troubleshooting{Style.RESET_ALL}")
        print(f"{Fore.WHITE}  • Ensure you ran: pip install -r requirements.txt{Style.RESET_ALL}\n")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
